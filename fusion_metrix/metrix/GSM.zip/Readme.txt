Matlab codes for Image Quality Assessment Based on Gradient Similarity.
GSM.p: main function
QE_GSIM_v2.m is the source code for the main function
Example.m: a simple example

The technical details have been described in the following paper:

A. Liu, W. Lin, M. Narwaria, ��Image Quality Assessment Based on Gradient Similarity,�� IEEE Transactions on Image Processing, vol. 21(4), pp. 1500-1512, 2012.